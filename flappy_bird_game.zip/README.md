# Flappy Bird — Minimal Clone

A simple browser-based Flappy Bird game built with pure HTML5 Canvas and JavaScript.

## How to play
- Click, tap, or press Space to flap.
- Avoid the pipes and ground.
- Press Enter to restart after a game over.

## Deployment on GitHub Pages
1. Create a new public repository on GitHub.
2. Upload `index.html` (this file) to the repository.
3. In repository settings, enable **GitHub Pages**:
   - Branch: `main`
   - Folder: `/ (root)`
4. Save. Your game will be available at:
   `https://<your-username>.github.io/<repository-name>/`
